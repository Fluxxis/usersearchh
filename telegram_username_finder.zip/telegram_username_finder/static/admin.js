const ADMIN_ID = window.ADMIN_ID;
const ADMIN_TOKEN = window.ADMIN_TOKEN;

function headers() {
  return {
    'X-Admin-Id': ADMIN_ID,
    'X-Admin-Token': ADMIN_TOKEN,
  };
}

async function apiGet(url) {
  const res = await fetch(url, { headers: headers() });
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}

async function apiPost(url, form) {
  const res = await fetch(url, {
    method: 'POST',
    headers: headers(),
    body: form,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok && !data.requires_password) throw new Error(data.error || JSON.stringify(data));
  return data;
}

function pretty(data) {
  return JSON.stringify(data, null, 2);
}

async function loadStatus() {
  const pill = document.getElementById('status-pill');
  const box = document.getElementById('status-box');
  try {
    const data = await apiGet('/api/admin/status');
    box.textContent = pretty(data);
    pill.textContent = data.authorized ? 'Telethon connected' : 'Telethon not connected';
    pill.className = 'status-pill ' + (data.authorized ? 'ok' : 'bad');
  } catch (err) {
    box.textContent = String(err);
    pill.textContent = 'status error';
    pill.className = 'status-pill bad';
  }
}

async function loadStats() {
  const box = document.getElementById('stats-box');
  const data = await apiGet('/api/admin/stats');
  box.innerHTML = `
    <div><b>${data.checks}</b><span>checks</span></div>
    <div><b>${data.found}</b><span>found</span></div>
    <div><b>${data.runs}</b><span>runs</span></div>
    <div><b>${data.checks_today}</b><span>today checks</span></div>
  `;
}

async function preview() {
  const length = document.getElementById('preview-length').value;
  const digits = document.getElementById('preview-digits').value;
  const list = document.getElementById('preview-list');
  list.innerHTML = '<span>loading</span>';
  const data = await apiGet(`/api/admin/generator/preview?length=${length}&digits=${digits}&count=24`);
  list.innerHTML = data.items.map(x => `<span>@${x}</span>`).join('');
}

document.getElementById('refresh-status').addEventListener('click', async () => {
  await loadStatus();
  await loadStats();
});

document.getElementById('preview-btn').addEventListener('click', preview);

document.getElementById('login-start').addEventListener('submit', async (e) => {
  e.preventDefault();
  const result = document.getElementById('login-result');
  result.textContent = 'Sending code...';
  try {
    const data = await apiPost('/api/admin/login/start', new FormData(e.target));
    result.textContent = data.ok ? 'Code sent. Enter it below.' : (data.error || 'Error');
  } catch (err) {
    result.textContent = String(err);
  }
});

document.getElementById('login-complete').addEventListener('submit', async (e) => {
  e.preventDefault();
  const result = document.getElementById('login-result');
  result.textContent = 'Completing login...';
  try {
    const data = await apiPost('/api/admin/login/complete', new FormData(e.target));
    result.textContent = data.ok ? `Connected: ${JSON.stringify(data.me)}` : (data.error || 'Error');
    await loadStatus();
  } catch (err) {
    result.textContent = String(err);
  }
});

document.getElementById('import-session').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await apiPost('/api/admin/session/import', form);
    alert(data.ok ? 'Session imported and authorized.' : 'Imported, but not authorized. Check api_id/api_hash/session file.');
    await loadStatus();
  } catch (err) {
    alert(String(err));
  }
});

loadStatus();
loadStats();
preview();
