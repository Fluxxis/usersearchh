from __future__ import annotations

import tempfile
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import get_settings
from app.auth import verify_admin_token
from app.generator import generate_usernames, explain_pattern
from app.telethon_checker import get_status, start_manual_login, complete_manual_login, import_session_file
from app import db

settings = get_settings()
db.init_db(settings.database_path)

app = FastAPI(title='Username Finder Admin')
app.mount('/static', StaticFiles(directory='static'), name='static')
templates = Jinja2Templates(directory='templates')


def require_admin(x_admin_id: str | None, x_admin_token: str | None) -> int:
    if not x_admin_id or not x_admin_token:
        raise HTTPException(status_code=401, detail='Missing admin auth')
    try:
        admin_id = int(x_admin_id)
    except ValueError as e:
        raise HTTPException(status_code=401, detail='Bad admin id') from e
    if not verify_admin_token(settings, admin_id, x_admin_token):
        raise HTTPException(status_code=403, detail='Forbidden')
    return admin_id


@app.get('/', response_class=HTMLResponse)
async def index() -> str:
    return '<meta name="viewport" content="width=device-width, initial-scale=1"><body style="font-family:system-ui;background:#080912;color:white;padding:30px">Username Finder WebApp is running.</body>'


@app.get('/admin', response_class=HTMLResponse)
async def admin_page(request: Request, admin_id: str, token: str):
    if not verify_admin_token(settings, int(admin_id), token):
        raise HTTPException(status_code=403, detail='Forbidden')
    return templates.TemplateResponse('admin.html', {
        'request': request,
        'admin_id': admin_id,
        'token': token,
        'telethon_api_id': settings.telethon_api_id or '',
        'telethon_api_hash': settings.telethon_api_hash or '',
    })


@app.get('/api/admin/status')
async def api_status(x_admin_id: str | None = Header(default=None), x_admin_token: str | None = Header(default=None)):
    require_admin(x_admin_id, x_admin_token)
    return await get_status(settings)


@app.get('/api/admin/stats')
async def api_stats(x_admin_id: str | None = Header(default=None), x_admin_token: str | None = Header(default=None)):
    require_admin(x_admin_id, x_admin_token)
    return db.get_stats(settings.database_path)


@app.get('/api/admin/generator/preview')
async def api_generator_preview(
    length: int = 6,
    digits: bool = False,
    count: int = 24,
    x_admin_id: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
):
    require_admin(x_admin_id, x_admin_token)
    count = max(1, min(count, 80))
    return {
        'items': generate_usernames(length=length, digits=digits, count=count),
        'explain': explain_pattern([]),
    }


@app.post('/api/admin/login/start')
async def api_login_start(
    api_id: int = Form(0),
    api_hash: str = Form(''),
    phone: str = Form(''),
    x_admin_id: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
):
    require_admin(x_admin_id, x_admin_token)
    try:
        final_api_id = api_id or settings.telethon_api_id
        final_api_hash = api_hash.strip() or settings.telethon_api_hash
        final_phone = phone.strip()
        if not final_api_id or not final_api_hash:
            raise ValueError('Заполни api_id и api_hash в config.json или в форме.')
        if not final_phone:
            raise ValueError('Введи номер телефона в WebApp.')
        return await start_manual_login(settings, final_api_id, final_api_hash, final_phone)
    except Exception as e:  # noqa: BLE001
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=400)


@app.post('/api/admin/login/complete')
async def api_login_complete(
    code: str = Form(...),
    password: str = Form(default=''),
    x_admin_id: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
):
    require_admin(x_admin_id, x_admin_token)
    result = await complete_manual_login(settings, code.strip(), password.strip() or None)
    status_code = 200 if result.get('ok') or result.get('requires_password') else 400
    return JSONResponse(result, status_code=status_code)


@app.post('/api/admin/session/import')
async def api_import_session(
    api_id: int = Form(0),
    api_hash: str = Form(''),
    file: UploadFile = File(...),
    x_admin_id: str | None = Header(default=None),
    x_admin_token: str | None = Header(default=None),
):
    require_admin(x_admin_id, x_admin_token)
    if not file.filename or not file.filename.endswith('.session'):
        raise HTTPException(status_code=400, detail='Upload a .session file')
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = Path(tmp.name)
    try:
        final_api_id = api_id or settings.telethon_api_id
        final_api_hash = api_hash.strip() or settings.telethon_api_hash
        if not final_api_id or not final_api_hash:
            raise ValueError('Заполни api_id и api_hash в config.json или в форме.')
        return await import_session_file(settings, final_api_id, final_api_hash, tmp_path)
    except Exception as e:  # noqa: BLE001
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=400)
    finally:
        tmp_path.unlink(missing_ok=True)


if __name__ == '__main__':
    import uvicorn
    uvicorn.run('webapp:app', host=settings.web_host, port=settings.web_port)
