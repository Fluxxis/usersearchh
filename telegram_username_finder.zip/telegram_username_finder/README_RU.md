# Telegram Username Finder Bot

Бот ищет свободные Telegram usernames по читаемым шаблонам вроде `sayuci`, `tucupo`, `zuduzi`, `goyize`, `wigijo`.

## Что есть

- Генератор нормальных юзов, а не мусорного рандома.
- Режимы 5 и 6 символов.
- Режим только буквы.
- Режим буквы + цифры.
- Проверка через Telethon-аккаунт.
- Защита от FloodWait через задержку.
- 16:9 PNG-плашки с найденными свободными юзами.
- Админ WebApp.
- Импорт `.session` файла.
- Ручная авторизация Telethon через api_id, api_hash, телефон, код и 2FA.
- Полный запуск на Ubuntu через `start.sh`.
- Бот, WebApp и Cloudflared запускаются в отдельных tmux-сессиях.

## Главный файл настроек

Теперь главный файл настроек: `config.json`.

Открой его:

```bash
nano config.json
```

Заполни:

```json
{
  "bot_token": "TOKEN_FROM_BOTFATHER",
  "admin_ids": [7225974704],
  "webapp_base_url": "http://127.0.0.1:8080",
  "admin_web_secret": "LONG_RANDOM_SECRET",
  "telethon": {
    "api_id": 123456,
    "api_hash": "your_api_hash"
  }
}
```

Номер телефона не хранится в `config.json`. Его вводишь в админ WebApp при авторизации Telethon.

`webapp_base_url` руками менять не надо, если запускаешь через `start.sh`. Скрипт сам получит ссылку Cloudflared и запишет её в `config.json`.

## Запуск на Ubuntu дедике

```bash
apt update
apt install -y unzip
unzip telegram_username_finder.zip
cd telegram_username_finder
nano config.json
bash start.sh
```

`start.sh` делает всё:

1. Ставит python3, venv, pip, curl, ca-certificates, tmux.
2. Ставит cloudflared.
3. Создаёт `.venv`.
4. Ставит зависимости из `requirements.txt`.
5. Запускает WebApp в tmux.
6. Запускает Cloudflared tunnel в tmux.
7. Берёт публичную ссылку `trycloudflare.com`.
8. Записывает её в `config.json`.
9. Запускает бота в tmux.

## tmux-сессии

Бот:

```bash
tmux attach -t username_finder_bot
```

WebApp:

```bash
tmux attach -t username_finder_webapp
```

Cloudflared:

```bash
tmux attach -t username_finder_cloudflared
```

Выйти из tmux без остановки:

```text
Ctrl+B, потом D
```

## Логи

```bash
tail -f logs/bot.log
tail -f logs/webapp.log
tail -f logs/cloudflared.log
```

## Админка

В Telegram напиши боту:

```text
/admin
```

Если твой Telegram ID есть в `admin_ids`, бот даст кнопку Admin WebApp.

## Telethon

Вариант 1. Через config.json:

```json
"telethon": {
  "api_id": 123456,
  "api_hash": "your_api_hash",
  "api_hash": "your_api_hash"
}
```

Потом зайди в `/admin`, введи номер в форме и нажми авторизацию.

Вариант 2. Через WebApp:

- введи `api_id`
- введи `api_hash`
- введи номер в WebApp
- введи код Telegram
- введи 2FA пароль, если он есть

Вариант 3. Импорт `.session`:

- открой `/admin`
- загрузи `.session`
- укажи api_id и api_hash или заранее заполни их в `config.json`

## Важно

Проверка свободных username не дает вечную гарантию. Username свободен только в момент проверки.

Не ставь `checker.delay_seconds` в 0. Это слабая идея. Telegram быстро даст FloodWait, и аккаунт перестанет нормально проверять юзы.
