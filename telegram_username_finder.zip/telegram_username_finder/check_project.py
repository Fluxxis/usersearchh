from app.generator import generate_usernames

print('5 letters:', generate_usernames(5, False, 10))
print('6 letters:', generate_usernames(6, False, 10))
print('5 with digits:', generate_usernames(5, True, 10))
print('6 with digits:', generate_usernames(6, True, 10))
print('OK')
