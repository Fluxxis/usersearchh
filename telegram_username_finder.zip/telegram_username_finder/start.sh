#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

CONFIG_FILE="${CONFIG_PATH:-config.json}"
LOG_DIR="logs"
mkdir -p "$LOG_DIR" data/telethon data/cards

echo "== Username Finder launcher =="

if [ ! -f "$CONFIG_FILE" ]; then
  cp config.example.json "$CONFIG_FILE"
  echo "Создан $CONFIG_FILE. Заполни bot_token, admin_ids, telethon.api_id, telethon.api_hash."
  echo "Команда: nano $CONFIG_FILE"
  exit 1
fi

if command -v apt >/dev/null 2>&1; then
  echo "== Проверяю пакеты Ubuntu =="
  apt update
  apt install -y python3 python3-venv python3-pip curl ca-certificates tmux
else
  echo "apt не найден. Скрипт рассчитан на Ubuntu/Debian."
  exit 1
fi

if ! command -v cloudflared >/dev/null 2>&1; then
  echo "== Устанавливаю cloudflared =="
  ARCH="$(uname -m)"
  if [ "$ARCH" = "x86_64" ] || [ "$ARCH" = "amd64" ]; then
    CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"
  elif [ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ]; then
    CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64"
  else
    echo "Неизвестная архитектура: $ARCH"
    exit 1
  fi
  curl -L "$CLOUDFLARED_URL" -o /usr/local/bin/cloudflared
  chmod +x /usr/local/bin/cloudflared
fi

echo "== Готовлю Python venv =="
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

read_cfg() {
  python3 - "$1" "$2" <<'PY'
import json, sys
path, key = sys.argv[1], sys.argv[2]
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)
cur = data
for part in key.split('.'):
    cur = cur.get(part, '') if isinstance(cur, dict) else ''
print(cur if cur is not None else '')
PY
}

BOT_TOKEN="$(read_cfg "$CONFIG_FILE" bot_token)"
WEB_HOST="$(read_cfg "$CONFIG_FILE" webapp.host)"
WEB_PORT="$(read_cfg "$CONFIG_FILE" webapp.port)"
BOT_SESSION="$(read_cfg "$CONFIG_FILE" tmux.bot_session)"
WEB_SESSION="$(read_cfg "$CONFIG_FILE" tmux.webapp_session)"
CLOUDFLARED_SESSION="$(read_cfg "$CONFIG_FILE" tmux.cloudflared_session)"
PUBLIC_URL_FILE="$(read_cfg "$CONFIG_FILE" cloudflared.public_url_file)"

WEB_HOST="${WEB_HOST:-0.0.0.0}"
WEB_PORT="${WEB_PORT:-8080}"
BOT_SESSION="${BOT_SESSION:-username_finder_bot}"
WEB_SESSION="${WEB_SESSION:-username_finder_webapp}"
CLOUDFLARED_SESSION="${CLOUDFLARED_SESSION:-username_finder_cloudflared}"
PUBLIC_URL_FILE="${PUBLIC_URL_FILE:-data/public_url.txt}"

if [ -z "$BOT_TOKEN" ] || [ "$BOT_TOKEN" = "PASTE_BOT_TOKEN_HERE" ]; then
  echo "Ошибка: заполни bot_token в $CONFIG_FILE"
  echo "Команда: nano $CONFIG_FILE"
  exit 1
fi

if [ "$WEB_HOST" = "127.0.0.1" ]; then
  UVICORN_HOST="127.0.0.1"
else
  UVICORN_HOST="0.0.0.0"
fi

echo "== Останавливаю старые tmux-сессии =="
tmux kill-session -t "$BOT_SESSION" 2>/dev/null || true
tmux kill-session -t "$WEB_SESSION" 2>/dev/null || true
tmux kill-session -t "$CLOUDFLARED_SESSION" 2>/dev/null || true
pkill -f "cloudflared tunnel --url http://127.0.0.1:$WEB_PORT" 2>/dev/null || true

: > "$LOG_DIR/webapp.log"
: > "$LOG_DIR/bot.log"
: > "$LOG_DIR/cloudflared.log"

echo "== Запускаю WebApp в tmux: $WEB_SESSION =="
tmux new-session -d -s "$WEB_SESSION" "cd '$PROJECT_DIR' && source .venv/bin/activate && python -m uvicorn webapp:app --host '$UVICORN_HOST' --port '$WEB_PORT' 2>&1 | tee -a '$LOG_DIR/webapp.log'"

sleep 2
if ! tmux has-session -t "$WEB_SESSION" 2>/dev/null; then
  echo "WebApp не запустился. Лог:"
  tail -n 80 "$LOG_DIR/webapp.log" || true
  exit 1
fi

echo "== Запускаю Cloudflared tunnel в tmux: $CLOUDFLARED_SESSION =="
tmux new-session -d -s "$CLOUDFLARED_SESSION" "cd '$PROJECT_DIR' && cloudflared tunnel --url 'http://127.0.0.1:$WEB_PORT' 2>&1 | tee -a '$LOG_DIR/cloudflared.log'"

PUBLIC_URL=""
for _ in $(seq 1 30); do
  PUBLIC_URL="$(grep -Eo 'https://[-a-zA-Z0-9]+\.trycloudflare\.com' "$LOG_DIR/cloudflared.log" | head -n 1 || true)"
  if [ -n "$PUBLIC_URL" ]; then
    break
  fi
  sleep 1
done

if [ -n "$PUBLIC_URL" ]; then
  mkdir -p "$(dirname "$PUBLIC_URL_FILE")"
  echo "$PUBLIC_URL" > "$PUBLIC_URL_FILE"
  python3 - "$CONFIG_FILE" "$PUBLIC_URL" <<'PY'
import json, sys
path, public_url = sys.argv[1], sys.argv[2]
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)
data['webapp_base_url'] = public_url
with open(path, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
    f.write('\n')
PY
  echo "Cloudflared URL: $PUBLIC_URL"
  echo "config.json обновлён: webapp_base_url=$PUBLIC_URL"
else
  echo "Не нашёл Cloudflared URL. Проверь лог: tail -f $LOG_DIR/cloudflared.log"
  echo "Бот запущу с текущим webapp_base_url из $CONFIG_FILE"
fi

echo "== Запускаю бота в tmux: $BOT_SESSION =="
tmux new-session -d -s "$BOT_SESSION" "cd '$PROJECT_DIR' && source .venv/bin/activate && python bot.py 2>&1 | tee -a '$LOG_DIR/bot.log'"

sleep 2
if ! tmux has-session -t "$BOT_SESSION" 2>/dev/null; then
  echo "Бот не запустился. Лог:"
  tail -n 80 "$LOG_DIR/bot.log" || true
  exit 1
fi

cat <<EOF

Готово.

WebApp local: http://127.0.0.1:$WEB_PORT
WebApp public: ${PUBLIC_URL:-проверь logs/cloudflared.log}

TMUX:
  bot:        tmux attach -t $BOT_SESSION
  webapp:     tmux attach -t $WEB_SESSION
  cloudflare: tmux attach -t $CLOUDFLARED_SESSION

Логи:
  tail -f logs/bot.log
  tail -f logs/webapp.log
  tail -f logs/cloudflared.log

Админка открывается через /admin в боте.
EOF
