from __future__ import annotations

import asyncio
import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from telethon import TelegramClient, functions, errors
from telethon.sessions import StringSession

from .config import Settings
from . import db


@dataclass
class CheckResult:
    username: str
    available: bool
    status: str
    error: str | None = None
    wait_seconds: int | None = None


_client_lock = asyncio.Lock()
_client: TelegramClient | None = None
_LOGIN_STATE: dict[str, Any] = {}


def _load_account(settings: Settings) -> dict[str, Any] | None:
    if settings.telethon_account_json.exists():
        with settings.telethon_account_json.open('r', encoding='utf-8') as f:
            return json.load(f)
    if settings.telethon_api_id and settings.telethon_api_hash:
        return {
            'api_id': int(settings.telethon_api_id),
            'api_hash': settings.telethon_api_hash,
        }
    return None


def _save_account(settings: Settings, api_id: int, api_hash: str) -> None:
    settings.telethon_account_json.parent.mkdir(parents=True, exist_ok=True)
    data = {'api_id': int(api_id), 'api_hash': api_hash}
    with settings.telethon_account_json.open('w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.chmod(settings.telethon_account_json, 0o600)


def session_exists(settings: Settings) -> bool:
    return settings.telethon_session_path.exists()


async def get_status(settings: Settings) -> dict[str, Any]:
    account = _load_account(settings)
    status = {
        'session_file': str(settings.telethon_session_path),
        'session_exists': session_exists(settings),
        'account_json_exists': settings.telethon_account_json.exists(),
        'authorized': False,
        'me': None,
        'error': None,
    }
    if not account or not session_exists(settings):
        return status
    try:
        client = TelegramClient(str(settings.telethon_session_path), int(account['api_id']), account['api_hash'])
        await client.connect()
        status['authorized'] = await client.is_user_authorized()
        if status['authorized']:
            me = await client.get_me()
            status['me'] = {
                'id': me.id,
                'username': me.username,
                'first_name': me.first_name,
                'phone': getattr(me, 'phone', None),
            }
        await client.disconnect()
    except Exception as e:  # noqa: BLE001
        status['error'] = str(e)
    return status


async def _get_client(settings: Settings) -> TelegramClient:
    global _client
    async with _client_lock:
        account = _load_account(settings)
        if not account:
            raise RuntimeError('Telethon account is not configured')
        if not settings.telethon_session_path.exists():
            raise RuntimeError('Telethon session file is missing')
        if _client is None:
            _client = TelegramClient(str(settings.telethon_session_path), int(account['api_id']), account['api_hash'])
            await _client.connect()
        elif not _client.is_connected():
            await _client.connect()
        if not await _client.is_user_authorized():
            raise RuntimeError('Telethon session is not authorized')
        return _client


async def check_username(settings: Settings, username: str) -> CheckResult:
    username = username.strip().replace('@', '').lower()
    try:
        client = await _get_client(settings)
        available = bool(await client(functions.account.CheckUsernameRequest(username=username)))
        result = CheckResult(username=username, available=available, status='ok')
        db.log_check(settings.database_path, username, available, 'ok')
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except errors.FloodWaitError as e:
        result = CheckResult(username=username, available=False, status='flood_wait', error=str(e), wait_seconds=int(e.seconds))
        db.log_check(settings.database_path, username, False, 'flood_wait', str(e))
        return result
    except errors.UsernameInvalidError as e:
        result = CheckResult(username=username, available=False, status='invalid', error=str(e))
        db.log_check(settings.database_path, username, False, 'invalid', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except errors.UsernameOccupiedError as e:
        result = CheckResult(username=username, available=False, status='occupied', error=str(e))
        db.log_check(settings.database_path, username, False, 'occupied', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except Exception as e:  # noqa: BLE001
        result = CheckResult(username=username, available=False, status='error', error=str(e))
        db.log_check(settings.database_path, username, False, 'error', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result


async def check_until_found(
    settings: Settings,
    candidates: list[str],
    target_count: int,
) -> tuple[list[CheckResult], list[CheckResult], int | None]:
    found: list[CheckResult] = []
    checked: list[CheckResult] = []
    flood_wait: int | None = None
    for username in candidates:
        if len(checked) >= settings.max_checks_per_request:
            break
        result = await check_username(settings, username)
        checked.append(result)
        if result.status == 'flood_wait':
            flood_wait = result.wait_seconds
            break
        if result.available:
            found.append(result)
            if len(found) >= target_count:
                break
    return found, checked, flood_wait


async def start_manual_login(settings: Settings, api_id: int, api_hash: str, phone: str) -> dict[str, Any]:
    global _LOGIN_STATE
    temp_path = settings.telethon_session_path.with_name('login_tmp.session')
    temp_path.parent.mkdir(parents=True, exist_ok=True)
    client = TelegramClient(str(temp_path), int(api_id), api_hash)
    await client.connect()
    sent = await client.send_code_request(phone)
    await client.disconnect()
    _LOGIN_STATE = {
        'api_id': int(api_id),
        'api_hash': api_hash,
        'phone': phone,
        'phone_code_hash': sent.phone_code_hash,
        'temp_path': str(temp_path),
    }
    return {'ok': True, 'phone': phone}


async def complete_manual_login(settings: Settings, code: str, password: str | None = None) -> dict[str, Any]:
    global _LOGIN_STATE, _client
    if not _LOGIN_STATE:
        return {'ok': False, 'error': 'Сначала запроси код.'}

    temp_path = Path(_LOGIN_STATE['temp_path'])
    client = TelegramClient(str(temp_path), int(_LOGIN_STATE['api_id']), _LOGIN_STATE['api_hash'])
    await client.connect()
    try:
        try:
            await client.sign_in(
                phone=_LOGIN_STATE['phone'],
                code=code,
                phone_code_hash=_LOGIN_STATE['phone_code_hash'],
            )
        except errors.SessionPasswordNeededError:
            if not password:
                await client.disconnect()
                return {'ok': False, 'requires_password': True, 'error': 'Нужен 2FA пароль.'}
            await client.sign_in(password=password)

        me = await client.get_me()
        await client.disconnect()
        settings.telethon_session_path.parent.mkdir(parents=True, exist_ok=True)
        if settings.telethon_session_path.exists():
            backup = settings.telethon_session_path.with_suffix('.session.bak')
            shutil.copy2(settings.telethon_session_path, backup)
        shutil.move(str(temp_path), str(settings.telethon_session_path))
        os.chmod(settings.telethon_session_path, 0o600)
        _save_account(settings, int(_LOGIN_STATE['api_id']), _LOGIN_STATE['api_hash'])
        _LOGIN_STATE = {}
        if _client:
            await _client.disconnect()
            _client = None
        return {
            'ok': True,
            'me': {'id': me.id, 'username': me.username, 'first_name': me.first_name},
        }
    except Exception as e:  # noqa: BLE001
        await client.disconnect()
        return {'ok': False, 'error': str(e)}


async def import_session_file(settings: Settings, api_id: int, api_hash: str, uploaded_path: Path) -> dict[str, Any]:
    global _client
    settings.telethon_session_path.parent.mkdir(parents=True, exist_ok=True)
    if settings.telethon_session_path.exists():
        shutil.copy2(settings.telethon_session_path, settings.telethon_session_path.with_suffix('.session.bak'))
    shutil.copy2(uploaded_path, settings.telethon_session_path)
    os.chmod(settings.telethon_session_path, 0o600)
    _save_account(settings, api_id, api_hash)
    if _client:
        await _client.disconnect()
        _client = None
    status = await get_status(settings)
    return {'ok': bool(status.get('authorized')), 'status': status}
