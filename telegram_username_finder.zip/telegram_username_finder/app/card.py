from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

CARD_SIZE = (1600, 900)


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _rounded_rect(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], radius: int, fill: tuple[int, int, int, int], outline=None, width: int = 1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def make_results_card(usernames: list[str], out_path: Path, title: str = 'FREE USERNAMES') -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    w, h = CARD_SIZE
    img = Image.new('RGB', CARD_SIZE, (8, 9, 13))
    px = img.load()
    for y in range(h):
        for x in range(w):
            r = int(8 + x / w * 32)
            g = int(9 + y / h * 24)
            b = int(18 + (x + y) / (w + h) * 52)
            px[x, y] = (r, g, b)

    glow = Image.new('RGBA', CARD_SIZE, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((900, -200, 1850, 750), fill=(105, 78, 255, 88))
    gd.ellipse((-220, 420, 650, 1250), fill=(0, 208, 255, 60))
    glow = glow.filter(ImageFilter.GaussianBlur(90))
    img = Image.alpha_composite(img.convert('RGBA'), glow)

    overlay = Image.new('RGBA', CARD_SIZE, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    _rounded_rect(draw, (110, 95, 1490, 805), 70, (255, 255, 255, 24), outline=(255, 255, 255, 72), width=2)
    _rounded_rect(draw, (145, 130, 1455, 770), 48, (0, 0, 0, 74), outline=(255, 255, 255, 35), width=1)

    title_font = _font(64, bold=True)
    sub_font = _font(30, bold=False)
    item_font = _font(52, bold=True)
    small_font = _font(24, bold=False)

    draw.text((185, 170), title, font=title_font, fill=(255, 255, 255, 245))
    draw.text((190, 247), 'length 5/6 · pronounceable · rate limited', font=sub_font, fill=(216, 224, 255, 170))

    if not usernames:
        draw.text((190, 430), 'No free usernames found in this run', font=item_font, fill=(255, 255, 255, 220))
    else:
        cols = 2 if len(usernames) > 5 else 1
        x_positions = [190, 845]
        y_start = 340
        step = 78
        for i, username in enumerate(usernames[:14]):
            col = i // 7 if cols == 2 else 0
            row = i % 7
            x = x_positions[col]
            y = y_start + row * step
            _rounded_rect(draw, (x - 18, y - 11, x + 535, y + 59), 23, (255, 255, 255, 24), outline=(255, 255, 255, 35), width=1)
            draw.text((x + 8, y), '@' + username.replace('@', ''), font=item_font, fill=(246, 248, 255, 245))

    draw.text((190, 730), 'Telegram Username Finder', font=small_font, fill=(255, 255, 255, 130))
    img = Image.alpha_composite(img, overlay).convert('RGB')
    img.save(out_path, 'PNG', optimize=True)
    return out_path
