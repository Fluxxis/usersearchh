from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import Iterable

SCHEMA = '''
CREATE TABLE IF NOT EXISTS checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    available INTEGER NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS found_usernames (
    username TEXT PRIMARY KEY,
    first_seen_at INTEGER NOT NULL,
    last_seen_at INTEGER NOT NULL,
    length INTEGER NOT NULL,
    has_digits INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS search_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    target_count INTEGER NOT NULL,
    generated_count INTEGER NOT NULL,
    checked_count INTEGER NOT NULL,
    found_count INTEGER NOT NULL,
    length INTEGER NOT NULL,
    digits INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);
'''


def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA journal_mode=WAL')
    return con


def init_db(path: Path) -> None:
    with connect(path) as con:
        con.executescript(SCHEMA)
        con.commit()


def log_check(path: Path, username: str, available: bool, status: str, error: str | None = None) -> None:
    now = int(time.time())
    with connect(path) as con:
        con.execute(
            'INSERT INTO checks(username, available, status, error, created_at) VALUES(?, ?, ?, ?, ?)',
            (username, int(available), status, error, now),
        )
        if available:
            con.execute(
                '''INSERT INTO found_usernames(username, first_seen_at, last_seen_at, length, has_digits)
                   VALUES(?, ?, ?, ?, ?)
                   ON CONFLICT(username) DO UPDATE SET last_seen_at=excluded.last_seen_at''',
                (username, now, now, len(username), int(any(ch.isdigit() for ch in username))),
            )
        con.commit()


def log_search_run(
    path: Path,
    user_id: int,
    target_count: int,
    generated_count: int,
    checked_count: int,
    found_count: int,
    length: int,
    digits: bool,
) -> None:
    with connect(path) as con:
        con.execute(
            '''INSERT INTO search_runs(user_id, target_count, generated_count, checked_count, found_count, length, digits, created_at)
               VALUES(?, ?, ?, ?, ?, ?, ?, ?)''',
            (user_id, target_count, generated_count, checked_count, found_count, length, int(digits), int(time.time())),
        )
        con.commit()


def get_recent_found(path: Path, limit: int = 30) -> list[str]:
    with connect(path) as con:
        rows = con.execute(
            'SELECT username FROM found_usernames ORDER BY last_seen_at DESC LIMIT ?',
            (limit,),
        ).fetchall()
    return [row['username'] for row in rows]


def get_stats(path: Path) -> dict[str, int]:
    with connect(path) as con:
        checks = con.execute('SELECT COUNT(*) AS c FROM checks').fetchone()['c']
        found = con.execute('SELECT COUNT(*) AS c FROM found_usernames').fetchone()['c']
        runs = con.execute('SELECT COUNT(*) AS c FROM search_runs').fetchone()['c']
        today = int(time.time()) - 86400
        checks_today = con.execute('SELECT COUNT(*) AS c FROM checks WHERE created_at >= ?', (today,)).fetchone()['c']
        found_today = con.execute('SELECT COUNT(*) AS c FROM found_usernames WHERE last_seen_at >= ?', (today,)).fetchone()['c']
    return {
        'checks': checks,
        'found': found,
        'runs': runs,
        'checks_today': checks_today,
        'found_today': found_today,
    }
