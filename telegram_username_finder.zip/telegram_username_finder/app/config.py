from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


CONFIG_PATH = Path(os.getenv('CONFIG_PATH', 'config.json'))


def _read_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    with CONFIG_PATH.open('r', encoding='utf-8') as f:
        return json.load(f)


def _deep_get(data: dict[str, Any], path: str, default: Any = None) -> Any:
    cur: Any = data
    for part in path.split('.'):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def _env_or_cfg(data: dict[str, Any], env_name: str, cfg_path: str, default: Any = None) -> Any:
    raw = os.getenv(env_name)
    if raw is not None and str(raw).strip() != '':
        return raw
    value = _deep_get(data, cfg_path, default)
    return value


def _required(value: Any, name: str) -> str:
    if value is None or str(value).strip() == '':
        raise RuntimeError(f'Missing required setting: {name}. Put it into config.json')
    return str(value).strip()


def _parse_admin_ids(value: Any) -> set[int]:
    if isinstance(value, list):
        return {int(x) for x in value if str(x).strip()}
    if value is None:
        return set()
    ids: set[int] = set()
    for part in str(value).replace(' ', '').split(','):
        if part:
            ids.add(int(part))
    return ids


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {'1', 'true', 'yes', 'y', 'on'}


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: set[int]
    webapp_base_url: str
    admin_web_secret: str
    database_path: Path
    telethon_session_path: Path
    telethon_account_json: Path
    telethon_api_id: int
    telethon_api_hash: str
    telethon_phone: str
    check_delay_seconds: float
    max_checks_per_request: int
    target_found_count: int
    web_host: str
    web_port: int
    cloudflared_enabled: bool
    cloudflared_public_url_file: Path
    tmux_session_bot: str
    tmux_session_webapp: str
    tmux_session_cloudflared: str


def get_settings() -> Settings:
    cfg = _read_config()

    telethon_api_id_raw = _env_or_cfg(cfg, 'TELETHON_API_ID', 'telethon.api_id', 0)
    try:
        telethon_api_id = int(telethon_api_id_raw or 0)
    except ValueError:
        telethon_api_id = 0

    return Settings(
        bot_token=_required(_env_or_cfg(cfg, 'BOT_TOKEN', 'bot_token'), 'bot_token'),
        admin_ids=_parse_admin_ids(_env_or_cfg(cfg, 'ADMIN_IDS', 'admin_ids', [])),
        webapp_base_url=str(_env_or_cfg(cfg, 'WEBAPP_BASE_URL', 'webapp_base_url', 'http://127.0.0.1:8080')).rstrip('/'),
        admin_web_secret=str(_env_or_cfg(cfg, 'ADMIN_WEB_SECRET', 'admin_web_secret', 'change_me_to_long_random_string')),
        database_path=Path(str(_env_or_cfg(cfg, 'DATABASE_PATH', 'database_path', 'data/app.sqlite3'))),
        telethon_session_path=Path(str(_env_or_cfg(cfg, 'TELETHON_SESSION_PATH', 'telethon.session_path', 'data/telethon/checker.session'))),
        telethon_account_json=Path(str(_env_or_cfg(cfg, 'TELETHON_ACCOUNT_JSON', 'telethon.account_json', 'data/telethon/account.json'))),
        telethon_api_id=telethon_api_id,
        telethon_api_hash=str(_env_or_cfg(cfg, 'TELETHON_API_HASH', 'telethon.api_hash', '') or ''),
        telethon_phone=str(os.getenv('TELETHON_PHONE', '') or ''),
        check_delay_seconds=float(_env_or_cfg(cfg, 'CHECK_DELAY_SECONDS', 'checker.delay_seconds', 1.7)),
        max_checks_per_request=int(_env_or_cfg(cfg, 'MAX_CHECKS_PER_REQUEST', 'checker.max_checks_per_request', 180)),
        target_found_count=int(_env_or_cfg(cfg, 'TARGET_FOUND_COUNT', 'checker.target_found_count', 10)),
        web_host=str(_env_or_cfg(cfg, 'WEB_HOST', 'webapp.host', '0.0.0.0')),
        web_port=int(_env_or_cfg(cfg, 'WEB_PORT', 'webapp.port', 8080)),
        cloudflared_enabled=_bool(_env_or_cfg(cfg, 'CLOUDFLARED_ENABLED', 'cloudflared.enabled', True), True),
        cloudflared_public_url_file=Path(str(_env_or_cfg(cfg, 'CLOUDFLARED_PUBLIC_URL_FILE', 'cloudflared.public_url_file', 'data/public_url.txt'))),
        tmux_session_bot=str(_env_or_cfg(cfg, 'TMUX_SESSION_BOT', 'tmux.bot_session', 'username_finder_bot')),
        tmux_session_webapp=str(_env_or_cfg(cfg, 'TMUX_SESSION_WEBAPP', 'tmux.webapp_session', 'username_finder_webapp')),
        tmux_session_cloudflared=str(_env_or_cfg(cfg, 'TMUX_SESSION_CLOUDFLARED', 'tmux.cloudflared_session', 'username_finder_cloudflared')),
    )
